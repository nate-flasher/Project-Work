//------------------------------------------------------------------------
// Starter kit for the maze solver problem. You have permission to use any
// of the code below, or to totally ignore it. -sb
//------------------------------------------------------------------------

#include <iostream>
#include <fstream>
#include <string>
#include "conio.h"

using namespace std;
using namespace conio;

void loadFile(char masterMatrix[10][10]);
void getStart(int& startRow, int& startCol);
bool canEscape(int row, int col, char masterMatrix[10][10]);

void main()
{
     int startRow, startCol;

     char masterMatrix[10][10];
     char matrix[10][10];

     // Call a function that prompts for the file name (e.g., "maze1.txt"),
     // reads the file and loads the maze characters into masterMatrix.
     loadFile(masterMatrix);

     // Call a function that prompts user for the starting row and column.
     // Reading the row and column from cin also causes a "priming read"
     // so that we can use "cin" as a boolean test for input data happiness. :-)
     getStart(startRow, startCol);

     // While the input stream is happy because the last read worked, keep looping.
     while(cin) {
        // Add your own code to copy the content of masterMatrix to matrix

        if( canEscape(startRow, startCol, matrix) ) {
            cout << "Happy day" << endl;
        } else {
            cout << "Less happy day" << endl;
        }
        getStart(startRow, startCol);
     }

     return 0;
}

void loadFile(char masterMatrix[10][10]) {
    string fileName;
    ifstream fileIn;
    cout << "Enter file name: ";
    cin >> fileName;
    fileIn.open( fileName.c_str() );

    while (!fileIn) {
        cout << "Couldn't open " << fileName << endl;
        fileIn.close();
        cout << "Enter file name: ";
        cin >> fileName;
        fileIn.open(fileName.c_str());
    }
    
    // Now go ahead and read in all the contents of the maze into masterMatrix

}

