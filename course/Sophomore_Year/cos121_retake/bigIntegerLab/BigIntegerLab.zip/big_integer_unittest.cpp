#include "big_integer.h"
#include "gtest/gtest.h"

TEST(BIGINTEGER, ADDTEST) {
    BigInteger a = BigInteger("50");
    BigInteger b = BigInteger("60");
    BigInteger c;
    c = a + b;
    EXPECT_EQ(c, BigInteger("110") );
    
}



TEST(BIGINTEGER, MULTIPLYTEST) {
    BigInteger a = BigInteger(123);
    BigInteger b = BigInteger(456);
    BigInteger c;
    c = a * b;
    EXPECT_EQ(c, 56088);
}



TEST(BIGINTEGER, LESSTHANTEST) {
    BigInteger a = BigInteger(8);
    BigInteger b = BigInteger(30);
    EXPECT_LT(a, b);
}



TEST(BIGINTEGER, EQUALTOTEST) {
    BigInteger a = BigInteger(63);
    BigInteger b = BigInteger(63);
    EXPECT_EQ(a, b);
}



TEST(BigInteger, STRINGTEST) {
    BigInteger myint = BigInteger(7);
    BigInteger mystring = BigInteger("7");

    EXPECT_EQ(myint, mystring);
}



TEST(BIGINTEGER, BIGBIGINTEGERADDTEST) {
    BigInteger bigIntString = BigInteger("578000000000");
    BigInteger bigIntString2 = BigInteger("1246000000000");
    BigInteger c;
    c = bigIntString + bigIntString2;
    EXPECT_EQ(c, BigInteger("1824000000000"));
}



TEST(BIGINTEGER, BIGBIGINTEGERMULTIPLYTEST) {
    BigInteger bigIntString = BigInteger("1230000000000");
    BigInteger bigIntString2 = BigInteger("150000000000");
    BigInteger c;
    c = bigIntString * bigIntString2;
    EXPECT_EQ(c, BigInteger("184500000000000000000000"));
}



TEST(BIGINTEGER, BIGBIGLESSTHANTEST) {
    BigInteger a = BigInteger("1000000000000");
    BigInteger b = BigInteger("1000000000001");
    EXPECT_LT(a, b);
}




TEST(BIGINTEGER, BIGBIGEQUALTOTEST) {
    BigInteger a = BigInteger("1000000000000");
    BigInteger b = BigInteger("1000000000000");
    EXPECT_EQ(a, b);
}




TEST(BigInteger, BIGBIGSTRINGTEST) {
    BigInteger myint = BigInteger("1000000000000");
    BigInteger mystring = BigInteger("1000000000000");

    EXPECT_EQ(myint, mystring);
}
